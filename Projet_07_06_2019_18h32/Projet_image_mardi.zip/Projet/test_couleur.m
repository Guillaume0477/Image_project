

I_couleur=im2double(imread('IMG_20190603_172012.jpg'));



figure(11)
imshow(I_couleur(:,:,:),[]);



figure(12)
I_snake = rgb2hsv(I_snake);
imshow(I_snake(:,:,:),[]);

