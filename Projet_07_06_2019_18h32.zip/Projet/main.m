%% Rotation
clear all;close all;

Img=imread('im15.jpg');
I_rotate=rotation_par_hough(Img,0.04,250,0.99);


%% anti reflet
figure(7)
I_open=open_image_couleur(I_rotate,'square',15);
title('abd')

%% boost couleur

I_open(:,:,1)=I_open(:,:,1)*1.5;
I_open(:,:,2)=I_open(:,:,2)*1.5;
I_open(:,:,3)=I_open(:,:,3)*1.5;
I_open=normalized_matrix_color(I_open);
figure(8)
imshow(I_open)

%% zoom

[x_min,x_max,y_min,y_max] = zoom_sur_resistance(I_open);
I_zoom=I_open(x_min:x_max,y_min:y_max,:);
figure(85)
imshow(I_zoom,[])
% [x_snake,y_snake]=snake(I_open,4.5,100,18,1000,2467,1998,200,150,500);
[hs,ws]=size(I_zoom(:,:,1));

%% mettre bon sens

I_zoom_gray=rgb2gray(I_rotate(x_min:x_max,y_min:y_max,:));
I_zoom_seuil=im2bw(I_zoom_gray,0.8);
figure(45)
subplot(131)
imshow(I_zoom_gray,[])
subplot(132)
imshow(I_zoom_seuil,[])

X=find(I_zoom_seuil);
[w,h]=size(I_zoom_seuil);
I_zoom_bs=I_zoom;
if mean(mean(X))<=(h*w)/2 %de droite à gauche
    I_zoom_bs=fliplr(I_zoom);
end
subplot(133)
imshow(I_zoom_bs);

%% compter bandes 

vec_mil=trouve_milieu_bande(I_zoom_bs);

