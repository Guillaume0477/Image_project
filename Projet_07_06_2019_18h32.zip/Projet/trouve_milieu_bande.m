function vec_mil=trouve_milieu_bande(I_open)

    [h,w]=size(I_open);

    figure(10)
    subplot(121)
    hold on
    [mean_r,mean_g,mean_b]=moyenne_colonne_matrix(I_open);
    plot(1:length(I_open(1,:,1)),mean_r,'r');
    plot(1:length(I_open(1,:,1)),mean_g,'g');
    plot(1:length(I_open(1,:,1)),mean_b,'b');

    subplot(122)
    hold on
    gradient_b=gradient(mean_b);
    plot(1:length(I_open(1,:,1)),gradient_b,'b');

    figure(11)
    subplot(121)
    hold on
    I_open_hsv = rgb2hsv(I_open);
    [mean_h,mean_s,mean_v]=moyenne_colonne_matrix(I_open_hsv);

    plot(1:length(I_open(1,:,1)),mean_h,'r');
    plot(1:length(I_open(1,:,1)),mean_s,'g');
    plot(1:length(I_open(1,:,1)),mean_v,'b');


    subplot(122)
    hold on
    gradient_s=gradient(mean_s);
    seuille=zeros(1,length(gradient_s));

    for k=1:length(gradient_s)
        if (abs(gradient_s(k))>=(0.10*max(gradient_s)))&&(abs(gradient_b(k))>=0.01) 
            seuille(k)=1;
        elseif (abs(gradient_s(k))>=(0.30*max(gradient_s)))
            seuille(k)=1;
        else
            seuille(k)=0;
        end
    end

    plot(1:length(I_open(1,:,1)),gradient_s,'g');

    check=1;
    for k=1:length(seuille)
        if check==1
            if seuille(k)==1
                check=0;
                cpt=0;
            end
        else
            if seuille(k)==1
                seuille(k)=0;
            end
            if cpt==floor(0.05*length(seuille))
                cpt=0;
                check=1;
            end
            cpt=cpt+1;
        end
    end

    vec_col=find(seuille);
    vec_mil=zeros(1,length(vec_col)/2);
    for k=1:length(vec_col)
        if mod(k,2)==0
            vec_mil(k/2)=round((vec_col(k-1)+vec_col(k))/2);
        end
    end

    figure(18)
    imshow(I_open,[]);
    for k=1:length(seuille)
        if seuille(k)==1
            figure(18)
            hold on
            plot([k,k],[1,h],'r')
        end
    end
end
